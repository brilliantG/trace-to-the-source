package com.suzhuoke.ncpsy.service;

import com.suzhuoke.ncpsy.model.Cjgly;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author RobinYoung10
 * @since 2019-02-22
 */
public interface ICjglyService extends IService<Cjgly> {

}
