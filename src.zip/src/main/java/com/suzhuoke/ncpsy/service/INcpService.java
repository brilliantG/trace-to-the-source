package com.suzhuoke.ncpsy.service;

import com.suzhuoke.ncpsy.model.Ncp;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author RobinYoung10
 * @since 2019-02-17
 */
public interface INcpService extends IService<Ncp> {

}
