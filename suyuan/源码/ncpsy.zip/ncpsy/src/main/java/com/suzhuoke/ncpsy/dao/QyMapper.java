package com.suzhuoke.ncpsy.dao;

import com.suzhuoke.ncpsy.model.Qy;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author RobinYoung10
 * @since 2019-02-17
 */
public interface QyMapper extends BaseMapper<Qy> {

}
