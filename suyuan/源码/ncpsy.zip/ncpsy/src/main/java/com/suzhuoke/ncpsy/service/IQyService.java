package com.suzhuoke.ncpsy.service;

import com.suzhuoke.ncpsy.model.Qy;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author RobinYoung10
 * @since 2019-02-17
 */
public interface IQyService extends IService<Qy> {

}
